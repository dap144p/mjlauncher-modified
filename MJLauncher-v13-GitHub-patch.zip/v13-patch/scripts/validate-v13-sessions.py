from pathlib import Path
import re, xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent.parent
app=p/'app_mojo/src/main'
ns={'android':'http://schemas.android.com/apk/res/android'}
a='{http://schemas.android.com/apk/res/android}'
root=ET.parse(app/'AndroidManifest.xml').getroot()
app_elem=root.find('application')
activities=app_elem.findall('activity'); services=app_elem.findall('service')
activity_map={v.get(a+'name'):v for v in activities}
service_map={v.get(a+'name'):v for v in services}
assert '.sessions.SessionChooserActivity' in activity_map
assert activity_map['.sessions.SessionChooserActivity'].get(a+'process') == ':sessionpicker'
for i in range(1,21):
    slot=f'{i:02d}'
    a_name=f'.game.GameActivity$Slot{slot}'
    s_name=f'.services.GameService$Slot{slot}'
    assert a_name in activity_map, a_name
    assert s_name in service_map, s_name
    assert activity_map[a_name].get(a+'process') == f':game{slot}'
    assert service_map[s_name].get(a+'process') == f':game{slot}'
for component in activities+services+app_elem.findall('provider'):
    attributes=component.attrib
    for key,val in attributes.items():
        if key in {a+'authorities',a+'taskAffinity'}:
            assert not ('git.artdeell.mjlaunch.' in val and 'v13.modified' not in val), val
activity=(app/'java/git/artdeell/mojo/game/GameActivity.java').read_text()
svc=(app/'java/git/artdeell/mojo/services/GameService.java').read_text()
manager=(app/'java/git/artdeell/mojo/sessions/SessionManager.java').read_text()
assert len(re.findall(r'public static class Slot\d\d extends GameActivity',activity)) == 20
assert len(re.findall(r'public static class Slot\d\d extends GameService',svc)) == 20
assert 'acquireGameDirectory' in manager and 'OverlappingFileLockException' in manager
assert 'mSlotLease' in activity and 'mGameDirectoryLease' in activity
assert 'SessionChooserActivity.class' in (app/'java/git/artdeell/mojo/utils/lifecycle/ContextAwareDoneListener.java').read_text()
build=(p/'app_mojo/build.gradle').read_text()
assert 'applicationId "git.artdeell.mjlaunch.v13.modified"' in build
assert "ctx.getExternalFilesDir(null)" in (app/'java/git/artdeell/mojo/Tools.java').read_text()
assert 'Tools.java' in (p/'scripts/apply-v13-source.sh').read_text()
assert "git.artdeell.mjlaunch.v13.modified.scoped.gamefolder" in build
print('PASS: 20 separate activity/service slots, separate processes, session chooser, locking, package identity, XML.')
