#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
import re,zipfile
base=Path(__file__).resolve().parent.parent
p=base/'app_mojo/src/main'
for path in [p/'AndroidManifest.xml',p/'res/xml/pref_video.xml',p/'res/values/strings.xml']:
    ET.parse(path)
jar=p/'assets/native-afk/afk-engine-v13.jar'
with zipfile.ZipFile(jar) as z:
    assert z.testzip() is None
    assert b'git.artdeell.mojo.afk.Agent' in z.read('META-INF/MANIFEST.MF')
    assert 'git/artdeell/mojo/afk/Bridge.class' in z.namelist()
manifest=(p/'AndroidManifest.xml').read_text()
assert manifest.count('android:stopWithTask="false"') == 21
assert 'git.artdeell.mjlaunch.v13.modified' in manifest
activity=(p/'java/git/artdeell/mojo/game/GameActivity.java').read_text()
runner=(p/'java/git/artdeell/mojo/utils/jre/GameRunner.java').read_text()
service=(p/'java/git/artdeell/mojo/services/GameService.java').read_text()
controller=(p/'java/git/artdeell/mojo/game/afk/AfkController.java').read_text()
for snippet in ['AfkController.prepare(this, slot)','AfkController.setBackground(true)','AfkController.setBackground(false)']:
    assert snippet in activity,snippet
assert 'AfkController.javaAgentArgument()' in runner
assert 'Process.killProcess(Process.myPid());' not in service.split('void onTaskRemoved')[1].split('onBind')[0]
assert 'v13_afk_enabled' in controller and 'v13_afk_1fps' in controller
assert 'slot-' in controller
assert (base/'scripts/apply-v13-source.sh').read_text().count('afk-engine-v13.jar') > 0
print('PASS v13 Android integration static checks; no claim of APK build or device runtime')
