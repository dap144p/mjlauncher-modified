#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo "usage: $0 /path/to/upstream" >&2; exit 2; fi
UPSTREAM="$1"
SOURCE="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$UPSTREAM/app_mojo/build.gradle"
cp "$SOURCE/app_mojo/build.gradle" "$UPSTREAM/app_mojo/build.gradle"
cp "$SOURCE/app_mojo/src/main/AndroidManifest.xml" "$UPSTREAM/app_mojo/src/main/AndroidManifest.xml"
mkdir -p "$UPSTREAM/app_mojo/src/main/java/git/artdeell/mojo/sessions"
cp -a "$SOURCE/app_mojo/src/main/java/git/artdeell/mojo/sessions/." "$UPSTREAM/app_mojo/src/main/java/git/artdeell/mojo/sessions/"
for f in Tools.java game/GameActivity.java services/GameService.java instances/Instances.java utils/lifecycle/ContextAwareDoneListener.java tasks/AsyncAssetManager.java; do
  cp "$SOURCE/app_mojo/src/main/java/git/artdeell/mojo/$f" "$UPSTREAM/app_mojo/src/main/java/git/artdeell/mojo/$f"
done
# AFK is an opt-out, process-local Java agent and does not patch GLFW/LWJGL natives.
mkdir -p "$UPSTREAM/app_mojo/src/main/java/git/artdeell/mojo/game/afk" "$UPSTREAM/app_mojo/src/main/assets/native-afk"
cp "$SOURCE/app_mojo/src/main/java/git/artdeell/mojo/game/afk/AfkController.java" "$UPSTREAM/app_mojo/src/main/java/git/artdeell/mojo/game/afk/AfkController.java"
cp "$SOURCE/app_mojo/src/main/java/git/artdeell/mojo/utils/jre/GameRunner.java" "$UPSTREAM/app_mojo/src/main/java/git/artdeell/mojo/utils/jre/GameRunner.java"
cp "$SOURCE/app_mojo/src/main/res/xml/pref_video.xml" "$UPSTREAM/app_mojo/src/main/res/xml/pref_video.xml"
cp "$SOURCE/app_mojo/src/main/res/values/strings.xml" "$UPSTREAM/app_mojo/src/main/res/values/strings.xml"
cp "$SOURCE/app_mojo/src/main/assets/native-afk/afk-engine-v13.jar" "$UPSTREAM/app_mojo/src/main/assets/native-afk/afk-engine-v13.jar"
printf 'Applied v13 session source overlay to %s\n' "$UPSTREAM"
