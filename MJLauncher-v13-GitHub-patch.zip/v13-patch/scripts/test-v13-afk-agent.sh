#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
javac --release 8 -d "$BUILD" "$ROOT"/afk-dev/tests/org/lwjgl/glfw/GLFW.java "$ROOT"/afk-dev/tests/org/lwjgl/opengl/GL11.java "$ROOT"/afk-dev/tests/org/lwjgl/openal/AL10.java "$ROOT"/afk-dev/tests/Game.java "$ROOT"/afk-dev/tests/AgentSmokeTest.java
java -javaagent:"$ROOT/app_mojo/src/main/assets/native-afk/afk-engine-v13.jar"="$BUILD/state/state" -cp "$BUILD" AgentSmokeTest "$BUILD/state"
