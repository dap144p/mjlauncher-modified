# V13 AFK 20 sessions — source preview (NOT a built APK)

Baseline: original Justicia H1 f6c5ae4, package `git.artdeell.mjlaunch.v13.modified`.

Includes 20 process-isolated session slots from previous v13 preview. This source overlay now also embeds an AFK Java instrumentation agent based on the user-provided v10 agent. Its Bridge runtime has been rebuilt (Java 8 bytecode) for 0 actual buffer presentations / up to 1 presentation per second during background. Draw call suppression uses prior-version EngineTransformer and applies only to supported LWJGL patterns, not to every renderer/version/mod.

## Behavior
- Activity onStop: process-local state file = background; onStart: foreground.
- Foreground service is kept alive when its task is swiped from Recents (previous source forcibly killed the JVM); notification Kill still terminates a session.
- When background and enabled: supported OpenGL draw calls and buffer presentation suppressed; optional up to 1 buffer presentation/sec (not guaranteed a complete refreshed world image); OpenAL master gain muted on supported OpenAL listeners.
- Minecraft's main loop is paced at approximately 20 iterations/s, not 1 iteration/s, to preserve opportunities for tick/game networking. This does NOT prove 20 TPS or guarantee online state on all versions/phones.
- No Minecraft `options.txt` modifications, so graphics/audio options will remain intact.
- On foreground: GL calls/SwapBuffers return to normal; audio restores on available audio callback.
- Background mode defaults ON; switch off in Video settings if startup crashes.
- Only starts AFK agent in the game JVM; does not change GLFW/LWJGL binaries.

## Important restrictions
- Local Java agent test passed with representative game bytecode, including a transformed GL draw call, 0 FPS, 1 FPS, and foreground restoration. Run `bash scripts/test-v13-afk-agent.sh`.
- **The Android launcher and APK were not built/tested** (Android Gradle/SDK/NDK unavailable here).
- Runtime instrumentation can be incompatible with some Minecraft versions, modded distributions or render backends; no universal guarantee.
- 0 FPS means *zero buffer swaps*, not stopping game logic or everything in the renderer. Remaining game CPU code and non-LWJGL graphics backends can still execute.
- Java runtime itself must support -javaagent (works in Java 8 test, not all runtimes/builds verified).
- Android may terminate the process in background; 'swipe away' and Force stop are not equivalent to putting the game in background.

## Test
Run `scripts/validate-v13-afk.py` to check static wiring. The agent smoke tests can be reproduced with the included `afk-tests` sources and a JDK; they do not require Android but cannot substitute for device testing.
