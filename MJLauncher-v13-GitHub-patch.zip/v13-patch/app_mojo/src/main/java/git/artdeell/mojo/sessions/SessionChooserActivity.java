package git.artdeell.mojo.sessions;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import git.artdeell.mojo.game.GameActivity;
import git.artdeell.mojo.prefs.LauncherPreferences;

/** Select a free game-process slot before any Minecraft rendering or JVM startup. */
public class SessionChooserActivity extends Activity {
    private boolean launched;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showSlots();
    }
    private void showSlots() {
        String[] labels = new String[SessionManager.MAX_SESSIONS];
        for(int i=0;i<labels.length;i++) {
            int slot=i+1;
            labels[i]="Session "+slot+(SessionManager.isRunning(this,slot)?" (running)":" (available)");
        }
        new AlertDialog.Builder(this).setTitle("Choose Minecraft session")
            .setItems(labels,(d,which)-> {
                int slot=which+1;
                if(SessionManager.isRunning(this,slot)) {
                    Toast.makeText(this,"Session already running. Choose another slot.",Toast.LENGTH_LONG).show();
                    showSlots();
                } else launch(slot);
            })
            .setNegativeButton(android.R.string.cancel,(d,w)->finish())
            .setOnCancelListener(d->finish())
            .show();
    }
    private void launch(int slot) {
        if(launched) return;
        launched=true;
        Intent start = new Intent(this, SessionManager.activityForSlot(slot));
        Intent source = getIntent();
        start.putExtra(GameActivity.INTENT_LAUNCH_VERSION, source.getStringExtra(GameActivity.INTENT_LAUNCH_VERSION));
        java.io.Serializable cp = source.getSerializableExtra(GameActivity.INTENT_LAUNCH_CLASSPATH);
        if(cp != null) start.putExtra(GameActivity.INTENT_LAUNCH_CLASSPATH,cp);
        String id=source.getStringExtra(SessionManager.EXTRA_INSTANCE_ID);
        if(id == null) id = LauncherPreferences.DEFAULT_PREF.getString(LauncherPreferences.PREF_KEY_CURRENT_INSTANCE, "");
        start.putExtra(SessionManager.EXTRA_INSTANCE_ID,id);
        start.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        startActivity(start);
        finish();
    }
}
