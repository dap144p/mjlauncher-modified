package git.artdeell.mojo.game.afk;

import android.content.Context;
import android.util.Log;

import git.artdeell.mojo.prefs.LauncherPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** State and bytecode-agent installation local to a single game process/slot. */
public final class AfkController {
    private static final String TAG = "MJ-AFK";
    private static File stateDirectory;
    private static File agentJar;
    private static boolean enabled;
    private AfkController() {}

    public static void prepare(Context context, int slot) {
        stateDirectory = new File(context.getCacheDir(), "v13-afk/slot-" + slot);
        enabled = preferencesEnabled();
        if (!stateDirectory.isDirectory() && !stateDirectory.mkdirs()) {
            Log.w(TAG, "No AFK state directory");
            enabled = false;
            return;
        }
        try {
            // Reset stale state on every new game process. Keep state within the
            // process-private cache; other slots must not change this state.
            writeByte("state", '0');
            writeByte("fps", preferOneFps() ? '1' : '0');
            writeByte("enabled", enabled ? '1' : '0');
            File destination = new File(context.getFilesDir(), "native-afk/slot-" + slot + "/afk-engine-v13.jar");
            if(!destination.getParentFile().isDirectory() && !destination.getParentFile().mkdirs())
                throw new IOException("Cannot create AFK jar directory");
            if(!destination.isFile() || destination.length() != 191536L) {
                // Always use the JAR bundled with this APK (not files from other
                // launcher versions); compare length only for a fast path.
                File pending = new File(destination.getParentFile(), "afk-engine-v13.tmp");
                try(InputStream input = context.getAssets().open("native-afk/afk-engine-v13.jar");
                    FileOutputStream output = new FileOutputStream(pending)) {
                    byte[] chunk = new byte[8192]; int n;
                    while((n = input.read(chunk)) >= 0) output.write(chunk, 0, n);
                    output.getFD().sync();
                }
                if(!pending.renameTo(destination)) {
                    if(!destination.delete() || !pending.renameTo(destination))
                        throw new IOException("Cannot replace AFK engine jar");
                }
            }
            agentJar = destination;
        } catch(IOException e) {
            Log.e(TAG, "AFK preparation failed; launch without agent", e);
            enabled = false;
            agentJar = null;
            try { writeByte("enabled", '0'); } catch(IOException ignored) { }
        }
    }
    private static boolean preferencesEnabled() {
        return LauncherPreferences.DEFAULT_PREF != null &&
                LauncherPreferences.DEFAULT_PREF.getBoolean("v13_afk_enabled", true);
    }
    private static boolean preferOneFps() {
        return LauncherPreferences.DEFAULT_PREF != null &&
                LauncherPreferences.DEFAULT_PREF.getBoolean("v13_afk_1fps", false);
    }
    private static void writeByte(String name, char value) throws IOException {
        if(stateDirectory == null) return;
        try(FileOutputStream file = new FileOutputStream(new File(stateDirectory, name), false)) {
            file.write((byte)value);
        }
    }
    public static void setBackground(boolean background) {
        if(!enabled || stateDirectory == null) return;
        try { writeByte("state", background ? '1' : '0'); }
        catch(IOException e) { Log.w(TAG,"Unable to update background state",e); }
    }
    /** Returns null when safely disabled/unavailable; does not mutate GLFW. */
    public static String javaAgentArgument() {
        if(!enabled || agentJar == null || !agentJar.isFile() || stateDirectory == null) return null;
        return "-javaagent:" + agentJar.getAbsolutePath() + "=" +
                new File(stateDirectory,"state").getAbsolutePath();
    }
}
