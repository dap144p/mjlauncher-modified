package git.artdeell.mojo.services;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import git.artdeell.mojo.game.GameActivity;
import git.artdeell.mojo.sessions.SessionManager;

import git.artdeell.mojo.R;
import git.artdeell.mojo.Tools;
import git.artdeell.mojo.utils.NotificationUtils;

import java.lang.ref.WeakReference;

public class GameService extends Service {
    private static final WeakReference<Service> sGameService = new WeakReference<>(null);
    private final LocalBinder mLocalBinder = new LocalBinder();

    @Override
    public void onCreate() {
        Tools.buildNotificationChannel(getApplicationContext());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(intent != null && intent.getBooleanExtra("kill", false)) {
            stopSelf();
            Process.killProcess(Process.myPid());
            return START_NOT_STICKY;
        }
        int slot=SessionManager.slotForClass(getClass());
        Intent killIntent = new Intent(getApplicationContext(), getClass());
        killIntent.putExtra("kill", true);
        PendingIntent pendingKillIntent = PendingIntent.getService(this, NotificationUtils.PENDINGINTENT_CODE_KILL_GAME_SERVICE + slot * 100
                , killIntent, Build.VERSION.SDK_INT >=23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 100 + slot,
                new Intent(this, slot > 0 ? SessionManager.activityForSlot(slot) : GameActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                 PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, "channel_id")
                .setContentTitle(getString(R.string.lazy_service_default_title))
                .setContentText(getString(R.string.notification_game_runs))
                .setContentIntent(contentIntent)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel,  getString(R.string.notification_terminate), pendingKillIntent)
                .setSmallIcon(R.drawable.notif_icon)
                .setNotificationSilent();

        Notification notification = notificationBuilder.build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NotificationUtils.NOTIFICATION_ID_GAME_SERVICE + slot * 100, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST);
        } else {
            startForeground(NotificationUtils.NOTIFICATION_ID_GAME_SERVICE + slot * 100, notification);
        }
        return START_NOT_STICKY; // non-sticky so android wont try restarting the game after the user uses the "Quit" button
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Home/Recents may remove the task while the foreground service is
        // still maintaining a game session. Do not kill the JVM here: the user
        // can stop this session using the persistent notification action.
        // Android may still kill the process under memory pressure.
        super.onTaskRemoved(rootIntent);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mLocalBinder;
    }

    public static class LocalBinder extends Binder {
        public boolean isActive;
    }

    public static class Slot01 extends GameService {}
    public static class Slot02 extends GameService {}
    public static class Slot03 extends GameService {}
    public static class Slot04 extends GameService {}
    public static class Slot05 extends GameService {}
    public static class Slot06 extends GameService {}
    public static class Slot07 extends GameService {}
    public static class Slot08 extends GameService {}
    public static class Slot09 extends GameService {}
    public static class Slot10 extends GameService {}
    public static class Slot11 extends GameService {}
    public static class Slot12 extends GameService {}
    public static class Slot13 extends GameService {}
    public static class Slot14 extends GameService {}
    public static class Slot15 extends GameService {}
    public static class Slot16 extends GameService {}
    public static class Slot17 extends GameService {}
    public static class Slot18 extends GameService {}
    public static class Slot19 extends GameService {}
    public static class Slot20 extends GameService {}
}
