package git.artdeell.mojo.sessions;

import android.app.ActivityManager;
import android.content.Context;
import git.artdeell.mojo.game.GameActivity;
import git.artdeell.mojo.services.GameService;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;

/** Separate OS processes for up to twenty game sessions. Never reuses the launcher process. */
public final class SessionManager {
    public static final int MAX_SESSIONS = 20;
    public static final String EXTRA_INSTANCE_ID = "mojo.session.instance_id";
    private SessionManager() {}
    public static int slotForClass(Class<?> type) {
        String name = type.getSimpleName();
        if(!name.startsWith("Slot")) return 0;
        try {
            int slot = Integer.parseInt(name.substring(4));
            return slot >= 1 && slot <= MAX_SESSIONS ? slot : 0;
        } catch(NumberFormatException e) { return 0; }
    }
    public static Class<? extends GameActivity> activityForSlot(int slot) {
        assertValidSlot(slot);
        try { return Class.forName("git.artdeell.mojo.game.GameActivity$Slot" + String.format(java.util.Locale.US,"%02d",slot)).asSubclass(GameActivity.class); }
        catch(ClassNotFoundException e) { throw new IllegalStateException("Missing session activity " + slot,e); }
    }
    public static Class<? extends GameService> serviceForSlot(int slot) {
        assertValidSlot(slot);
        try { return Class.forName("git.artdeell.mojo.services.GameService$Slot" + String.format(java.util.Locale.US,"%02d",slot)).asSubclass(GameService.class); }
        catch(ClassNotFoundException e) { throw new IllegalStateException("Missing session service " + slot,e); }
    }
    public static void assertValidSlot(int slot) {
        if(slot < 1 || slot > MAX_SESSIONS) throw new IllegalArgumentException("Invalid session slot: " + slot);
    }
    public static boolean isRunning(Context ctx,int slot) {
        assertValidSlot(slot);
        ActivityManager manager = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        if(manager == null || manager.getRunningAppProcesses() == null) return false;
        String processName = ctx.getPackageName() + ":game" + String.format(java.util.Locale.US,"%02d",slot);
        for(ActivityManager.RunningAppProcessInfo process : manager.getRunningAppProcesses()) {
            if(processName.equals(process.processName)) return true;
        }
        return false;
    }
    public static SlotLease acquire(Context ctx,int slot) throws IOException {
        assertValidSlot(slot);
        return acquireNamedLock(ctx,"game-" + slot);
    }
    /** Shared writable game directories may not be used by two processes concurrently. */
    public static SlotLease acquireGameDirectory(Context ctx, File gameDir) throws IOException {
        String canonicalPath = gameDir.getCanonicalPath();
        // UUID.nameUUIDFromBytes is a stable, filesystem-safe key for the canonical path.
        String key = java.util.UUID.nameUUIDFromBytes(
                canonicalPath.getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();
        return acquireNamedLock(ctx,"data-" + key);
    }
    private static SlotLease acquireNamedLock(Context ctx,String name) throws IOException {
        File locks = new File(ctx.getFilesDir(),"session-locks");
        if(!locks.isDirectory() && !locks.mkdirs()) throw new IOException("Unable to create session locks");
        File file = new File(locks,name + ".lock");
        RandomAccessFile raf = new RandomAccessFile(file,"rw");
        try {
            FileLock lock = raf.getChannel().tryLock();
            if(lock == null) { raf.close(); return null; }
            return new SlotLease(raf,lock);
        } catch(OverlappingFileLockException e) { raf.close(); return null; }
        catch(IOException e) { raf.close(); throw e; }
    }
    public static class SlotLease implements AutoCloseable {
        private final RandomAccessFile file;
        private final FileLock lock;
        private SlotLease(RandomAccessFile file, FileLock lock) { this.file=file; this.lock=lock; }
        @Override public void close() throws IOException { try { lock.release(); } finally { file.close(); } }
    }
}
