package git.artdeell.mojo.afk;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.LockSupport;

/**
 * Process-local renderer presentation gate.
 * Draw calls are skipped by EngineTransformer while hidden; this class only
 * gates GLFW swaps and OpenAL master gain. It NEVER waits for a whole second:
 * preventing the client thread from advancing would also stop game ticks.
 */
public final class Bridge {
    private static volatile File stateFile;
    private static volatile File enabledFile;
    private static volatile File fpsFile;
    private static volatile boolean hidden;
    private static volatile int backgroundFps;
    private static volatile long nextRead;
    private static final ThreadLocal<Long> lastPresent = new ThreadLocal<>();
    private static final ConcurrentHashMap<Class<?>, Audio> audio = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Class<?>, Method> swaps = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Class<?>, Method> gains = new ConcurrentHashMap<>();
    private static final int AL_GAIN = 0x100A;
    private static final long CONFIG_REFRESH_NS = 100_000_000L;
    private static final long FRAME_NS = 1_000_000_000L;
    private static final long MAX_TICK_WAIT_NS = 50_000_000L;
    private Bridge() {}

    public static synchronized void initialize(String statePath) {
        if (statePath == null || statePath.length() == 0) return;
        stateFile = new File(statePath);
        enabledFile = new File(stateFile.getParentFile(), "enabled");
        fpsFile = new File(stateFile.getParentFile(), "fps");
        nextRead = 0;
        hidden = false;
        backgroundFps = 0;
    }
    private static int readByte(File file, int fallback) {
        if (file == null || !file.isFile()) return fallback;
        try(FileInputStream in = new FileInputStream(file)) {
            int value = in.read();
            return value < 0 ? fallback : value;
        } catch(IOException ignored) { return fallback; }
    }
    public static boolean background() {
        final long now = System.nanoTime();
        if (now >= nextRead) {
            synchronized(Bridge.class) {
                if (now >= nextRead) {
                    hidden = readByte(enabledFile, '0') == '1' && readByte(stateFile, '0') == '1';
                    backgroundFps = readByte(fpsFile, '0') == '1' ? 1 : 0;
                    nextRead = now + CONFIG_REFRESH_NS;
                }
            }
        }
        return hidden;
    }
    public static boolean suppressRender(boolean previous) {
        return previous || background();
    }
    private static Method cachedMethod(ConcurrentHashMap<Class<?>, Method> cache,
                                       Class<?> clazz, String name, Class<?>... arguments) {
        Method m = cache.get(clazz);
        if(m != null) return m;
        try {
            m = clazz.getMethod(name, arguments);
            cache.putIfAbsent(clazz, m);
            return m;
        }catch(ReflectiveOperationException e) { throw new IllegalStateException(e); }
    }
    private static void invoke(Method method, Object... args) {
        try { method.invoke(null, args); }
        catch(InvocationTargetException e) {
            Throwable cause = e.getCause();
            if(cause instanceof Error) throw (Error)cause;
            if(cause instanceof RuntimeException) throw (RuntimeException)cause;
            throw new IllegalStateException(cause);
        }catch(ReflectiveOperationException e) { throw new IllegalStateException(e); }
    }
    public static void swapBuffers(long window, Class<?> api) {
        // The audio listener is OpenAL thread-owned. Render callbacks may not own
        // its context; attempt to restore/mute only from that same thread.
        final long threadId = Thread.currentThread().getId();
        for(Audio a:audio.values()) if(a.gainThread == threadId) audioPulse(a.api);
        Method original = cachedMethod(swaps, api, "glfwSwapBuffers", long.class);
        if(!background()) {
            lastPresent.remove();
            invoke(original, window);
            return;
        }
        long now = System.nanoTime();
        Long last = lastPresent.get();
        if (backgroundFps == 1 && (last == null || now - last >= FRAME_NS)) {
            lastPresent.set(now);
            // The actual GL draw calls are gated while background, so this is
            // a minimal refresh, not a fully rendered 1 FPS world frame.
            invoke(original, window);
        }
        // Keep client-loop opportunities at about 20/s. Never sleep for 1s:
        // Minecraft integrates game ticks into its frame loop on some versions.
        LockSupport.parkNanos(MAX_TICK_WAIT_NS);
    }
    public static void listenerGain(int parameter, float value, Class<?> api) {
        Audio a = audio.computeIfAbsent(api, Audio::new);
        synchronized(a) {
            if(parameter == AL_GAIN) {
                a.requested = value;
                a.muted = background();
                a.gainThread = Thread.currentThread().getId();
            }
            Method original = cachedMethod(gains, api, "alListenerf", int.class, float.class);
            invoke(original, parameter, (parameter == AL_GAIN && a.muted) ? 0f : value);
        }
    }
    public static void audioPulse(Class<?> api) {
        Audio a = audio.get(api);
        if(a == null || a.gainThread != Thread.currentThread().getId()) return;
        synchronized(a) {
            boolean shouldMute = background();
            if(a.muted == shouldMute) return;
            a.muted = shouldMute;
            invoke(cachedMethod(gains, api, "alListenerf", int.class, float.class),
                    AL_GAIN, shouldMute ? 0f : a.requested);
        }
    }
    static final class Audio {
        final Class<?> api;
        float requested = 1f;
        boolean muted;
        volatile long gainThread;
        Audio(Class<?> api) {this.api=api;}
    }
}
