package org.lwjgl.openal;
public class AL10 {
 public static float gain=1f;
 public static void alListenerf(int what,float value){if(what==0x100A)gain=value;}
}
