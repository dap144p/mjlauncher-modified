package org.lwjgl.opengl;
public class GL11 {
 public static int draws;
 public static void glDrawArrays(int mode,int first,int count){draws++;}
}
