package org.lwjgl.glfw;
public class GLFW {
 public static int swaps;
 public static void glfwSwapBuffers(long window){swaps++;}
}
