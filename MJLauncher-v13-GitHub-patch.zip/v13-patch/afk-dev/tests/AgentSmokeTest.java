import java.nio.file.*;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;
import org.lwjgl.openal.AL10;
public class AgentSmokeTest {
 static void value(Path p, String s)throws Exception{ Files.write(p,s.getBytes("UTF-8"));Thread.sleep(130);}
 static void check(boolean b,String msg){ if(!b)throw new AssertionError(msg);}
 public static void main(String[] args) throws Exception{
   Path dir=Paths.get(args[0]); Files.createDirectories(dir);
   Path enabled=dir.resolve("enabled"),state=dir.resolve("state"),fps=dir.resolve("fps");
   value(enabled,"1");value(state,"0");value(fps,"0");
   Game game=new Game();game.setVolume(0.42f);game.render();check(Math.abs(AL10.gain-0.42f)<0.0001f,"volume initial");check(GLFW.swaps==1 && GL11.draws==1,"foreground must draw and swap");
   value(state,"1");int oldSwaps=GLFW.swaps,oldDraws=GL11.draws;
   for(int i=0;i<3;i++)game.render();
   check(GLFW.swaps==oldSwaps && GL11.draws==oldDraws,"background zero should suppress draw and swaps");
   check(AL10.gain==0f,"background audio should be muted");
   value(fps,"1");oldSwaps=GLFW.swaps;
   for(int i=0;i<3;i++)game.render();check(GLFW.swaps>=oldSwaps && GLFW.swaps<=oldSwaps+1,"background fallback must present at most one frame per second");
   value(state,"0");game.render();check(Math.abs(AL10.gain-0.42f)<0.0001f,"foreground audio restored");check(GLFW.swaps>=oldSwaps+1 && GL11.draws==oldDraws+1,"foreground must restore draw and swaps");
   System.out.println("PASS native-free JVM AFK smoke test: draw calls suppressed, 0/1 swaps, audio muted/restored");
 }
}
