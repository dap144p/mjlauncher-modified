import org.lwjgl.opengl.GL11;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.openal.AL10;
public class Game {
 public void setVolume(float gain){AL10.alListenerf(0x100A,gain);}
 public void render(){GL11.glDrawArrays(4,0,3);GLFW.glfwSwapBuffers(1L);}
}
